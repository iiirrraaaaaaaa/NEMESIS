$(document).ready(function(){
    $('.block__title').click(function(event){
        $(this).next().slideToggle(300);
    });
});