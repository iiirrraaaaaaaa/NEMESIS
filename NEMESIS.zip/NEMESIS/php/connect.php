<?php
    $mysql = new mysqli('localhost', 'root', '', 'nemesis');
?>